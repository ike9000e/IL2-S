#ifndef _IL2S_API_H_INCLUDED_
#define _IL2S_API_H_INCLUDED_

#include <inttypes.h>

#ifdef __GNUC__
#	if __GNUC__ >= 4
#		define IL2S_EAPI __attribute__ ((visibility("default")))
#	else
#		define IL2S_EAPI
#	endif
#else
# define IL2S_EAPI
#endif

/// Main Imlib image type.
typedef void* IL2S_Image;

/// Type of blending operation to use,
/// Used fe. on il2s_blend_image_onto_image() call.
typedef enum
{
   IL2S_OP_COPY = 0,
   IL2S_OP_ADD,
   IL2S_OP_SUBTRACT,
   IL2S_OP_RESHADE,
} IL2S_Operation;

/// Definition of flags used by the interface functions.
enum{
	/// Formerly imlib_context_set_anti_alias().
	/// Used on:
	/// * il2s_create_cropped_scaled_image()
	/// * il2s_blend_image_onto_image()
	/// * il2s_create_rotated_image()
	/// * ...
	IL2S_AntiAlias = 0x1,
	/// Formerly imlib_context_set_blend().
	/// Used on:
	/// * il2s_blend_image_onto_image()
	/// * il2s_image_fill_rectangle
	/// * il2s_image_draw_rectangle
	/// * ...
	IL2S_Blend = 0x2,
	/// Formerly ''char merge_alpha''.
	/// Used on:
	/// * il2s_blend_image_onto_image()
	IL2S_MergeAlpha = 0x4,
};

/**
	Structure for recieving info from optional ImLib function
	callbacks.

	\sa il2s_progress_cb
*/
typedef struct {
	/// User pointer, returned as set durning original call.
	void*  userr;
	/// Percentage as fraction in range from 0.0 to 1.0, inclusivelly.
	/// Though range is inclusive, it shouldn't be assumed that the first
	/// call will have it set to 0.0, neither final to 1.0.
	/// Expect first call to have it set to value >= 0.0,
	/// increased in each consecutive call.
	float  fPercentage;
	/// Begining and ending position, part of the image that the
	/// progress callback refers to. Both, 'nBgnPixel' and 'nEndPixel',
	/// are set to zero if the info is not available.
	int    nBgnPixel, nEndPixel;
	/// If available, contains pointer to the image that is
	/// being created by the processing function, otherwise NULL.
	IL2S_Image img;
} IL2S_Progress;

/// Progress callback function type, generally used throughout the library.
/// The callback must return true (integer 1) to cause
/// the operation to continue, false to cancel.
/// \sa IL2S_Progress
typedef int(*il2s_progress_cb)( const IL2S_Progress* inp );

/// Rectangle structure.
typedef struct
{
	int x,y,w,h;

} IL2S_Rect;

#ifdef __cplusplus
	extern "C" {
#endif

		IL2S_EAPI void
		il2s_init();

		IL2S_EAPI void
		il2s_deinit();

		IL2S_EAPI IL2S_Image
		il2s_create_image( int width, int height );

		IL2S_EAPI void
		il2s_free_image( IL2S_Image img2 );

		IL2S_EAPI IL2S_Image
		il2s_create_image_using_data( int width, int height, uint32_t* data );

		IL2S_EAPI IL2S_Image
		il2s_create_image_using_copied_data( int width, int height, const uint32_t* data );

		IL2S_EAPI const uint32_t*
		il2s_image_get_data_for_reading_only( IL2S_Image img2 );

		IL2S_EAPI uint32_t*
		il2s_image_get_data( IL2S_Image img2 );

		IL2S_EAPI void
		il2s_image_put_back_data( IL2S_Image img2, uint32_t* data );

		IL2S_EAPI IL2S_Image
		il2s_create_cropped_scaled_image( IL2S_Image img,
									IL2S_Rect source_rect,
									int destination_width, int destination_height,
									int nFlags,
									il2s_progress_cb calb2, void* userr );
		IL2S_EAPI void
		il2s_blend_image_onto_image( IL2S_Image source_image,
									IL2S_Rect source_rect,
									IL2S_Image dest_image,
									IL2S_Rect dest_rect,
									IL2S_Operation eOperation, int nFlags,
									il2s_progress_cb calb2, void* userr );

		IL2S_EAPI uint32_t
		il2s_color_cmya_to_rgba( int cyan, int magenta, int yellow,
									int alphaa );
		IL2S_EAPI void
		il2s_color_rgba_to_cmya( uint32_t color,
					int *cyan, int *magenta, int *yellow, int* alphaa );
		IL2S_EAPI uint32_t
		il2s_color_hsva_to_rgba( float huee, float saturationn, float valuee, int alphaa );
		IL2S_EAPI void
		il2s_color_rgba_to_hsva( uint32_t clr, float *h, float *s, float *v, int *alphaa );

		IL2S_EAPI int
		il2s_image_copy_alpha_rectangle_to_image( IL2S_Image image_source,
									IL2S_Rect source_rect,
									IL2S_Image image_dest,
									int destination_x, int destination_y,
									il2s_progress_cb calb2, void* userr );

		IL2S_EAPI int
		il2s_image_has_alpha( IL2S_Image img2 );
		IL2S_EAPI void
		il2s_image_set_has_alpha( IL2S_Image img2, int has_alpha );
		IL2S_EAPI uint32_t
		il2s_image_query_pixel( IL2S_Image img2, int x, int y );
		IL2S_EAPI void
		il2s_image_copy_rect( IL2S_Image img2,
									IL2S_Rect source_rect,
									int new_x, int new_y,
									il2s_progress_cb calb2, void* userr );
		IL2S_EAPI IL2S_Image
		il2s_create_rotated_image( IL2S_Image img2, double angle, int nFlags,
										il2s_progress_cb calb2, void* userr );
		IL2S_EAPI int
		il2s_image_get_width( IL2S_Image img2 );
		IL2S_EAPI int
		il2s_image_get_height( IL2S_Image img2 );

		IL2S_EAPI int
		il2s_image_fill_rectangle( IL2S_Image img2,
				IL2S_Rect rect,
				uint32_t color, IL2S_Operation eOperation, int nFlags,
				il2s_progress_cb calb2, void* userr );

		IL2S_EAPI int
		il2s_image_draw_rectangle( IL2S_Image img2,
								IL2S_Rect rect,
								uint32_t color, IL2S_Operation eOperation, int nFlags,
								il2s_progress_cb calb2, void* userr );

		IL2S_EAPI void
		il2s_image_draw_ellipse( IL2S_Image img2, int xc, int yc,
								int a, int b, uint32_t color,
								IL2S_Operation eOperation, int nFlags );

		IL2S_EAPI void
		il2s_image_fill_ellipse( IL2S_Image img2, int xc, int yc,
								int a, int b, uint32_t color,
								IL2S_Operation eOperation, int nFlags );

		IL2S_EAPI void
		il2s_image_draw_line( IL2S_Image img2,
								int x1, int y1, int x2, int y2,
								uint32_t color, IL2S_Operation eOperation, int nFlags );

#ifdef __cplusplus
	}
#endif

/// Internal, helper structure.
typedef struct {
	il2s_progress_cb calb3;
	void*  userr;
} _IL2S_InnerProgress;

/// Internal, helper function.
int _il2s_call_user_callback( const _IL2S_InnerProgress* ipr, float fPrc,
					int nBgnPix, int nEndPix,
					IL2S_Image img4 );

/// Internal, granularity variable.
extern const int _IL2S_ProgressGranularity;

/*
	Fork status:

x	imlib_context_set_color_hsva --> __imlib_hsv_to_rgb
x	imlib_context_set_color_cmya
x	imlib_image_query_pixel_cmya
x	imlib_image_query_pixel
x	imlib_image_copy_alpha_rectangle_to_image
x	imlib_image_copy_alpha_to_image
x	imlib_image_copy_rect
x	imlib_image_has_alpha --> IMAGE_HAS_ALPHA
x	imlib_image_set_has_alpha
x	imlib_create_rotated_image
x	imlib_image_draw_rectangle
x	imlib_image_fill_rectangle
x	imlib_image_draw_ellipse
x	imlib_image_fill_ellipse
x	imlib_image_draw_line
	imlib_image_fill_color_range_rectangle
	imlib_image_fill_hsva_color_range_rectangle
	imlib_context_set_color_hlsa --> __imlib_hls_to_rgb
	imlib_image_draw_polygon
	imlib_image_fill_polygon	(	ImlibPolygon 	poly	 )
	imlib_image_tile
	imlib_image_tile_horizontal
	imlib_image_tile_vertical
*/
#endif // _IL2S_API_H_INCLUDED_

//-std=c++11
