#include "../inc/il2s/il2s_api.h"
#include "il2s_colormod.h"
#include "il2s_scale.h"
#include "il2s_blend.h"
#include "il2s_rotate.h"
#include "il2s_rgbadraw.h"
#include "il2s_updates.h"

int const _IL2S_ProgressGranularity = 8;

#define   CHECK_PARAM_POINTER_RETURN(func, sparam, param, ret)
#define   CHECK_PARAM_POINTER(func, sparam, param)

/**
 * @param width The width of the image.
 * @param height The height of the image.
 * @param data The data.
 * @return A valid image, otherwise NULL.
 *
 * Creates an image from the image data specified with the width @p width and
 * the height @p height specified. The image data @p data must be in the same format as
 * imlib_image_get_data() would return. You are responsible for
 * freeing this image data once the image is freed - Imlib2 will not
 * do that for you. This is useful for when you already have static
 * buffers of the same format Imlib2 uses (many video grabbing devices
 * use such a format) and wish to use Imlib2 to render the results
 * onto another image, or X drawable. You should free the image when
 * you are done with it. Imlib2 returns a valid image handle on
 * success or NULL on failure
 *
 * old: imlib_create_image_using_data()
 **/
IL2S_EAPI IL2S_Image
il2s_create_image_using_data( int width, int height, uint32_t* data )
{
   ImlibImage         *im;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_create_image_using_data", "data", data,
							  NULL);
   if ((width <= 0) || (height <= 0))
	  return NULL;
   im = __imlib_CreateImage( width, height, data );
   if (im)
	  SET_FLAG(im->flags, F_DONT_FREE_DATA);
   return (IL2S_Image) im;
}

/**
 * @param width The width of the image.
 * @param height The height of the image.
 * @param data The data.
 * @return A valid image, otherwise NULL.
 *
 * Works the same way as il2s_create_image_using_data() but Imlib2
 * copies the image data to the image structure. You may now do
 * whatever you wish with the original data as it will not be needed
 * anymore. Imlib2 returns a valid image handle on success or NULL on
 * failure.
 *
 * old: imlib_create_image_using_copied_data()
 **/
IL2S_EAPI IL2S_Image
il2s_create_image_using_copied_data( int width, int height, const uint32_t* data )
{
   ImlibImage         *im;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_create_image_using_copied_data", "data",
							  data, NULL);
   if ((width <= 0) || (height <= 0))
	  return NULL;
   im = __imlib_CreateImage(width, height, NULL);
   if (!im)
	  return NULL;
   im->data = malloc(width * height * sizeof(uint32_t));
   if (data)
	 {
		memcpy(im->data, data, width * height * sizeof(uint32_t));
		return (IL2S_Image) im;
	 }
   else
	  __imlib_FreeImage(im);
   return NULL;
}
/**
	@param width The width of the image.
	@param height The height of the image.
	@return A new blank image.

	Creates a new blank image of size @p width and @p height. The contents of
	this image at creation time are undefined (they could be garbage
	memory). You are free to do whatever you like with this image. It
	is not cached. On success an image handle is returned - on failure
	NULL is returned.

	old: imlib_create_image()
*/
IL2S_EAPI IL2S_Image
il2s_create_image( int width, int height )
{
   uint32_t* data;
   if( (width <= 0) || (height <= 0) )
      return NULL;
   data = malloc(width * height * sizeof(uint32_t));
   if (data)
      return (IL2S_Image) __imlib_CreateImage(width, height, data);
   return NULL;
}

/// Internal function.
__hidden int
_il2s_call_user_callback( const _IL2S_InnerProgress* ipr, float fPrc,
								int nBgnPix, int nEndPix,
								IL2S_Image img4 )
{
	if( ipr && ipr->calb3 ){
		IL2S_Progress prgr;
		prgr.userr       = ipr->userr;
		prgr.fPercentage = fPrc;
		prgr.nBgnPixel   = nBgnPix;
		prgr.nEndPixel   = nEndPix;
		prgr.img         = 0;
		return ipr->calb3( &prgr );
	}
	return 1;
}
__hidden
void imlib_free_font()
{
	assert(!"Not implemented [RjcWeBTCG].");
}
__hidden
void imlib_free_filter()
{
	assert(!"Not implemented [NFjvY0LQcr].");
}
__hidden
void imlib_free_color_modifier()
{
	assert(!"Not implemented [F0fBXBRfp].");
}

/**
 * Frees the image that is set as the current image in Imlib2's context.
 *
 * old: imlib_free_image()
 */
IL2S_EAPI void
il2s_free_image( IL2S_Image img2 )
{
   //CHECK_CONTEXT(ctx);
   //CHECK_PARAM_POINTER("imlib_free_image", "image", ctx->image);
   //__imlib_FreeImage(ctx->image);
   //ctx->image = NULL;

   CHECK_PARAM_POINTER("il2s_free_image", "image", img2);
   __imlib_FreeImage( img2 );
}

/**
	@return A pointer to the image data.

	Functions the same way as imlib_image_get_data(), but returns a
	pointer expecting the program to NOT write to the data returned (it
	is for inspection purposes only). Writing to this data has undefined
	results. The data does not need to be put back.

	The image data is returned in the format of a uint32_t (32 bits) per
	pixel in a linear array ordered from the top left of the image to
	the bottom right going from left to right each line. Each pixel
	has the upper 8 bits as the alpha channel and the lower 8 bits are
	the blue channel - so a pixel's bits are ARGB (from most to least
	significant, 8 bits per channel).
*/
IL2S_EAPI const uint32_t*
il2s_image_get_data_for_reading_only( IL2S_Image img2 )
{
   ImlibImage         *im3;

   //CHECK_CONTEXT(ctx);
   //CHECK_PARAM_POINTER_RETURN("imlib_image_get_data_for_reading_only",
   //                           "image", ctx->image, NULL);
   //CAST_IMAGE(im3, ctx->image);
   im3 = img2;
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
	  im3->loader->load(im3, NULL, 0, 1);
   if (!im3->data)
	  return NULL;
   return im3->data;
}



/* dirty and image by settings its invalid flag */
__hidden void
__il2s_DirtyImage(ImlibImage * im)
{
   SET_FLAG(im->flags, F_INVALID);
   /* and dirty all pixmaps generated from it */
   __imlib_DirtyPixmapsForImage(im);
}

/**
	Works the same as imlib_create_cropped_image() but will scale the
	new image to the new destination @p destination_width and
	@p destination_height whilst cropping.

	@param source_x The top left x coordinate of the source rectangle.
	@param source_y The top left y coordinate of the source rectangle.
	@param source_width The width of the source rectangle.
	@param source_height The height of the source rectangle.
	@param destination_width The width of the destination image.
	@param destination_height The height of the destination image.
	@param nFlags - Flags, eg. IL2S_AntiAlias.
	@param il2s_progress_cb - Progress callback function.
	       In case of this function, percentages sends thru callback
	       can be translated into number of lines completed.

	@return A valid image, otherwise NULL.

	old: imlib_create_cropped_scaled_image()
*/
IL2S_EAPI IL2S_Image
il2s_create_cropped_scaled_image( IL2S_Image img2,
							//	int source_x, int source_y,
							//	int source_width, int source_height,
								IL2S_Rect rcSource,
								int destination_width, int destination_height,
								int nFlags,
								il2s_progress_cb calb2, void* userr )
{
	_IL2S_InnerProgress sProgress = { calb2, userr,};
	ImlibImage *im3, *im_old;
	int rv2 = 1, bAntiAlias = !!( nFlags & IL2S_AntiAlias );

	int source_x = rcSource.x, source_y = rcSource.y,
			source_width = rcSource.w, source_height = rcSource.h;

   //CHECK_CONTEXT(ctx);
   //CHECK_PARAM_POINTER_RETURN("imlib_create_cropped_scaled_image", "image",
   //                           ctx->image, NULL);
   //CAST_IMAGE(im_old, ctx->image);
   im_old = img2;
   if ((!(im_old->data)) && (im_old->loader) && (im_old->loader->load))
	  im_old->loader->load(im_old, NULL, 0, 1);
   if (!(im_old->data))
	  return NULL;
   im3 = __imlib_CreateImage(abs(destination_width), abs(destination_height),
							NULL);
   im3->data =
	  malloc(abs(destination_width * destination_height) * sizeof(uint32_t));
   if (!(im3->data))
	 {
		__imlib_FreeImage(im3);
		return NULL;
	 }
   if (IMAGE_HAS_ALPHA(im_old))
	 {
		SET_FLAG(im3->flags, F_HAS_ALPHA);
		rv2 = __imlib_BlendImageToImage(im_old, im3, bAntiAlias, 0, 1, source_x,
								  source_y, source_width, source_height, 0, 0,
								  destination_width, destination_height, NULL,
								  IL2S_OP_COPY,
								  //ctx->cliprect.x, ctx->cliprect.y, ctx->cliprect.w, ctx->cliprect.h
								  0,0,0,0,
								  &sProgress );
	 }
   else
	 {
		//ctx->anti_alias
		rv2 = __imlib_BlendImageToImage(im_old, im3, bAntiAlias, 0, 0, source_x,
								  source_y, source_width, source_height, 0, 0,
								  destination_width, destination_height, NULL,
								  IL2S_OP_COPY,
								  //ctx->cliprect.x, ctx->cliprect.y, ctx->cliprect.w, ctx->cliprect.h
								  0,0,0,0,
								  &sProgress );
	 }
   if(!rv2){
	  if(im3){
		 __imlib_FreeImage(im3);
		 im3 = 0;
	  }
	  return NULL;
   }else{
	  return (IL2S_Image) im3;
   }
}
/**
	@param source_image The source image.
	@param merge_alpha Alpha flag.
	@param source_x X coordinate of the source image.
	@param source_y Y coordinate of the source image.
	@param source_width Width of the source image.
	@param source_height Height of the source image.
	@param destination_x X coordinate of the destination image.
	@param destination_y Y coordinate of the destination image.
	@param destination_width Width of the destination image.
	@param destination_height Height of the destination image.

	@param nFlags - flags, 0 or combination of:
					* \ref IL2S_AntiAlias
					* \ref IL2S_Blend
	                * \ref IL2S_MergeAlpha

	@param eOperation - Eg. IL2S_OP_COPY. Formerly imlib_context_set_operation().

	Blends the source rectangle (@p source_x, @p source_y, @p
	source_width, @p source_height) from
	@p source_image onto the current image at the destination (@p
	destination_x, @p destination_y) location
	scaled to the width @p destination_width and height @p
	destination_height. If @p merge_alpha is set to 1
	it will also modify the destination image alpha channel, otherwise
	the destination alpha channel is left untouched.

	old: imlib_blend_image_onto_image()
 */
IL2S_EAPI void
il2s_blend_image_onto_image( IL2S_Image source_image,
							IL2S_Rect source_rect,
							IL2S_Image dest_image,
							IL2S_Rect dest_rect,
							IL2S_Operation eOperation, int nFlags,
							il2s_progress_cb calb2, void* userr )
{
	ImlibImage*         im_src, *im_dst;
	int                 bAntiAlias2, bBlend, bMergeAlpha;
	_IL2S_InnerProgress sProgress = { calb2, userr,};

	int source_x = source_rect.x, source_y = source_rect.y,
		source_width = source_rect.w, source_height = source_rect.h,
		destination_x = dest_rect.x, destination_y = dest_rect.y,
		destination_width = dest_rect.w, destination_height = dest_rect.h;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER("imlib_blend_image_onto_image", "source_image",
					   source_image);
   //CHECK_PARAM_POINTER("imlib_blend_image_onto_image", "image", ctx->image);
   //CAST_IMAGE(im_src, source_image);
   im_src = source_image;
   //CAST_IMAGE(im_dst, ctx->image);
   CHECK_PARAM_POINTER("imlib_blend_image_onto_image", "image", dest_image);
   im_dst = dest_image;

   if ((!(im_src->data)) && (im_src->loader) && (im_src->loader->load))
	  im_src->loader->load(im_src, NULL, 0, 1);
   if (!(im_src->data))
	  return;
   if ((!(im_dst->data)) && (im_dst->loader) && (im_dst->loader->load))
	  im_dst->loader->load(im_dst, NULL, 0, 1);
   if (!(im_dst->data))
	  return;
   __il2s_DirtyImage(im_dst);
   //bAntiAlias2 = ctx->anti_alias;
   bAntiAlias2 = !!(nFlags & IL2S_AntiAlias);
   bBlend      = !!(nFlags & IL2S_Blend);   //old: ctx->blend
   bMergeAlpha = !!(nFlags & IL2S_MergeAlpha); // old: char merge_alpha

   if ((abs(destination_width) < (source_width >> 7))
	   || (abs(destination_height) < (source_height >> 7))){
	  // FIXME: hack to get around infinite loops for scaling down too far.
	  bAntiAlias2 = 0;
   }
   // ctx->color_modifier --> imlib_context_set_color_modifier()
   // ctx->operation      --> imlib_context_set_operation()

   __imlib_BlendImageToImage(im_src, im_dst, bAntiAlias2, bBlend, bMergeAlpha,
							 source_x, source_y, source_width,
							 source_height, destination_x, destination_y,
							 destination_width, destination_height,
							 0,   //ctx->color_modifier,
							 eOperation,  //ctx->operation,
							 //ctx->cliprect.x, ctx->cliprect.y, ctx->cliprect.w, ctx->cliprect.h
							 0,0,0,0,
							 &sProgress );
}

/// Imlib2 initialization function. Should be called only once
/// per process, before any other Imlib2 function.
IL2S_EAPI void il2s_init()
{
	__imlib_build_pow_lut();
}
/// Imlib2 deinitialization function. Complement for il2s_init().
/// Currently does nothing.
IL2S_EAPI void il2s_deinit()
{
}

/**
	@param huee Hue channel of the current color.
	@param saturationn Saturation channel of the current color.
	@param valuee Value channel of the current color.
	@param alphaa Alpha channel..., 0-255.

	Sets the color in HSVA space. Values for @p h are between 0 and 360,
	values for @p s and @p v between 0.0 and 1.0, and values for
	@p alphaa are between 0 and 255 - any other values have undefined
	results.

	old: __imlib_hsv_to_rgb()
*/
IL2S_EAPI uint32_t
il2s_color_hsva_to_rgba( float huee, float saturationn, float valuee,
							int alphaa )
{
   float               f, vf;
   int                 i, p, q, t, vv;
   int                 r, g, b;

   vf = 255.0 * valuee;
   vv = (int)round(vf);

   if (saturationn == 0.0){
		r = g = b = vv;
		return 00;
   }else{

	   huee /= 60.0;
	   i = floor(huee);
	   f = huee - (float)i;
	   p = (int)round(vf * (1.0 - saturationn));
	   q = (int)round(vf * (1.0 - (saturationn * f)));
	   t = (int)round(vf * (1.0 - saturationn * (1.0 - f)));

	   switch (i % 6)
		 {
		 case 0:
			r = vv;
			g = t;
			b = p;
			break;
		 case 1:
			r = q;
			g = vv;
			b = p;
			break;
		 case 2:
			r = p;
			g = vv;
			b = t;
			break;
		 case 3:
			r = p;
			g = q;
			b = vv;
			break;
		 case 4:
			r = t;
			g = p;
			b = vv;
			break;
		 case 5:
		 default:
			r = vv;
			g = p;
			b = q;
			break;
		 }
		 return ( alphaa<<24 | r<<16 | g<<8 | b );
	 }
}

/**
	@param clr Color in 0xAARRGGBB format.
	@param h Hue channel of the current color.
	@param s Saturation channel of the current color.
	@param v Value channel of the current color.
	@param alphaa Alpha channel of the current color.

	Returns color in the HSVA space.

	old: imlib_context_get_color_hsva()
*/
IL2S_EAPI void
il2s_color_rgba_to_hsva( uint32_t clr, float *h, float *s, float *v, int *alphaa )
{
	float               min, max, delta;

	int r = (clr >> 16) & 0xFF;
	int g = (clr >> 8 ) & 0xFF;
	int b = (clr      ) & 0xFF;
	*alphaa = (clr >> 24) & 0xFF;

   min = (((r < g) ? r : g) < b) ? ((r < g) ? r : g) : b;
   max = (((r > g) ? r : g) > b) ? ((r > g) ? r : g) : b;

   *v = max / 255.0;
   delta = (max - min);
   if (delta == 0)
     {
        *h = 0.0;
        *s = 0.0;
        return;
     }
   *s = delta / max;
   if (r == max)
      *h = (g - b) / delta;
   else if (g == max)
      *h = 2.0 + (b - r) / delta;
   else
      *h = 4.0 + (r - g) / delta;
   *h *= 60.0;
   if (*h < 0)
      *h += 360.0;
}


/**
	@param cyan Cyan channel of the current color.
	@param magenta Magenta channel of the current color.
	@param yellow Yellow channel of the current color.
	@param alphaa Alpha channel of the current color.

	Sets the color in CMYA space. Values for @p cyan, @p magenta, @p yellow and
	@p alphaa are between 0 and 255 - any other values have undefined
	results.

	old: imlib_context_set_color_cmya()
*/
IL2S_EAPI uint32_t
il2s_color_cmya_to_rgba( int cyan, int magenta, int yellow, int alphaa )
{
	int r = 255 - cyan;
	int g = 255 - magenta;
	int b = 255 - yellow;
	return ( ( alphaa<<24 ) | ( r<<16 ) | ( g<<8 ) | b );
}
/**
	@param cyan The returned cyan channel.
	@param magenta The returned magenta channel.
	@param yellow The returned yellow channel.

	Gets the CMYA color.

	old: imlib_image_query_pixel_cmya()
*/
IL2S_EAPI void
il2s_color_rgba_to_cmya( uint32_t colorRGB,
							int *cyan, int *magenta, int *yellow, int* alphaa )
{
	int r = (colorRGB >> 16) & 0xFF;
	int g = (colorRGB >> 8 ) & 0xFF;
	int b = (colorRGB      ) & 0xFF;
	*alphaa = (colorRGB >> 24) & 0xFF;
	*cyan    = 255 - r;
	*magenta = 255 - g;
	*yellow  = 255 - b;
}

__hidden int
__imlib_copy_alpha_data( ImlibImage * src, ImlibImage * dst, int x, int y,
                        int w, int h, int nx, int ny,
                        _IL2S_InnerProgress* sProgress )
{
   int                 xx, yy, jump, jump2;
   uint32_t             *p1, *p2, *prevPos;

   /* clip horizontal co-ordinates so that both dest and src fit inside */
   /* the image */
   if (x < 0)
     {
        w += x;
        nx -= x;
        x = 0;
     }
   if (w <= 0)
      return 1;
   if (nx < 0)
     {
        w += nx;
        x -= nx;
        nx = 0;
     }
   if (w <= 0)
      return 1;
   if ((x + w) > src->w)
      w = (src->w - x);
   if (w <= 0)
      return 1;
   if ((nx + w) > dst->w)
      w = (dst->w - nx);
   if (w <= 0)
      return 1;
   /* clip vertical co-ordinates so that both dest and src fit inside */
   /* the image */
   if (y < 0)
     {
        h += y;
        ny -= y;
        y = 0;
     }
   if (h <= 0)
      return 1;
   if (ny < 0)
     {
        h += ny;
        y -= ny;
        ny = 0;
     }
   if (h <= 0)
      return 1;
   if ((y + h) > src->h)
      h = (src->h - y);
   if (h <= 0)
      return 1;
   if ((ny + h) > dst->h)
      h = (dst->h - ny);
   if (h <= 0)
      return 1;

   /* figure out what our source and destnation start pointers are */
   p1 = src->data + (y * src->w) + x;
   p2 = dst->data + (ny * dst->w) + nx;
   /* the pointer jump between lines */
   jump = (src->w - w);
   jump2 = (dst->w - w);
   prevPos = p2;
   /* work our way thru the array */
   for (yy = 0; yy < h; yy++)
     {
        for (xx = 0; xx < w; xx++)
          {
             *p2 = (*p1 & 0xff000000) | (*p2 & 0x00ffffff);
             p1++;
             p2++;
          }
        p1 += jump;
        p2 += jump2;
		if( sProgress && sProgress->calb3 ){   //_IL2S_InnerProgress*
			const int bIfLastLine = (yy+1 == h);
			const int bEveryNthLine = !(yy % _IL2S_ProgressGranularity);
			if( bIfLastLine || bEveryNthLine ){
				float fPrc = ((double)(yy+1)) / h; //yields: 0.0 - 1.0
				int b = prevPos - dst->data;
				int e = p2 - dst->data;
				if(!_il2s_call_user_callback( sProgress, fPrc, b,e, 0 )){
					return 0;
				}
				prevPos = p2;
			}
		}
     }
     return 1;
}
/**
	@param image_source An image.
	@param x The top left x coordinate of the rectangle.
	@param y The top left y coordinate of the rectangle.
	@param width The width of the rectangle.
	@param height The height of the rectangle.
	@param destination_x The top left x coordinate of the destination rectangle.
	@param destination_y The top left x coordinate of the destination rectangle.

	Copies the source (@p x, @p y, @p width, @p height) rectangle alpha channel from
	the source image @p image_source and replaces the alpha channel on the destination
	image at the (@p destination_x, @p destination_y) coordinates.

	old: imlib_image_copy_alpha_rectangle_to_image()
	-    imlib_image_copy_alpha_to_image()
*/
IL2S_EAPI int
il2s_image_copy_alpha_rectangle_to_image( IL2S_Image image_source,
								IL2S_Rect source_rect,
								IL2S_Image image_dest,
								int destination_x, int destination_y,
								il2s_progress_cb calb2, void* userr )
{
	ImlibImage *im0, *im2;
	_IL2S_InnerProgress sProgress = { calb2, userr,};
	int x = source_rect.x, y = source_rect.y,
			width = source_rect.w, height = source_rect.h;

   CHECK_PARAM_POINTER("imlib_image_copy_alpha_rectangle_to_image",
                       "image_source", image_source);
   CHECK_PARAM_POINTER("imlib_image_copy_alpha_rectangle_to_image",
                       "image_destination", image_dest);
   im0 = image_source;
   im2 = image_dest;
   if ((!(im0->data)) && (im0->loader) && (im0->loader->load))
      im0->loader->load(im0, NULL, 0, 1);
   if ((!(im2->data)) && (im2->loader) && (im2->loader->load))
      im2->loader->load(im2, NULL, 0, 1);
   if (!(im0->data))
      return 1;
   if (!(im2->data))
      return 1;
   SET_FLAG(im0->flags, F_INVALID);   //__imlib_DirtyImage(im0);
   return __imlib_copy_alpha_data(im0, im2, x, y, width, height, destination_x,
                           destination_y, &sProgress );
}
/**
	@return Current alpha channel flag.

	Returns 1 if the current context image has an alpha channel, or 0
	if it does not (the alpha data space is still there and available -
	just "unused").

	old: imlib_image_has_alpha()
*/
IL2S_EAPI int
il2s_image_has_alpha( IL2S_Image img2 )
{
   ImlibImage         *im = img2;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_image_has_alpha", "image", ctx->image, 0);
   //CAST_IMAGE(im, ctx->image);
   if (IMAGE_HAS_ALPHA(im))
      return 1;
   return 0;
}
/**
	@param has_alpha Alpha flag.

	Sets the alpha flag for the current image. Set @p has_alpha to 1 to
	enable the alpha channel in the current image, or 0 to disable it.
*/
IL2S_EAPI void
il2s_image_set_has_alpha( IL2S_Image img2, int has_alpha )
{
   ImlibImage         *im3 = img2;

   if (has_alpha)
      SET_FLAG(im3->flags, F_HAS_ALPHA);
   else
      UNSET_FLAG(im3->flags, F_HAS_ALPHA);
}
/**
	@param x The x coordinate of the pixel.
	@param y The y coordinate of the pixel.

	@return 32-bir ARGB color.

	Fills the @p color_return color structure with the color of the pixel
	in the current image that is at the (@p x, @p y) location specified.

	old: imlib_image_query_pixel()
*/
IL2S_EAPI uint32_t
il2s_image_query_pixel( IL2S_Image img2, int x, int y )
{
   ImlibImage         *im3 = img2;
   uint32_t             *p;

   CHECK_PARAM_POINTER("il2s_image_query_pixel", "image", img2);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!(im3->data))
      return 0;
   if ((x < 0) || (x >= im3->w) || (y < 0) || (y >= im3->h))
     {;
        return 0;
     }
   p = im3->data + (im3->w * y) + x;
   int r = ((*p) >> 16) & 0xff;
   int g = ((*p) >> 8) & 0xff;
   int b = (*p) & 0xff;
   int a = ((*p) >> 24) & 0xff;
   return ( ( a<<24 ) | ( r<<16 ) | ( g<<8 ) | b );
}
__hidden int
__imlib_copy_image_data( ImlibImage * im, int x, int y, int w, int h, int nx,
                        int ny, const _IL2S_InnerProgress* sProgress )
{
   int                 xx, yy, jump;
   uint32_t             *p1, *p2;

   // clip horizontal co-ordinates so that both dest and src fit inside
   // the image
   if (x < 0)
     {
        w += x;
        nx -= x;
        x = 0;
     }
   if (w <= 0)
      return 1;
   if (nx < 0)
     {
        w += nx;
        x -= nx;
        nx = 0;
     }
   if (w <= 0)
      return 1;
   if ((x + w) > im->w)
      w = (im->w - x);
   if (w <= 0)
      return 1;
   if ((nx + w) > im->w)
      w = (im->w - nx);
   if (w <= 0)
      return 1;
   // clip vertical co-ordinates so that both dest and src fit inside
   // the image
   if (y < 0)
     {
        h += y;
        ny -= y;
        y = 0;
     }
   if (h <= 0)
      return 1;
   if (ny < 0)
     {
        h += ny;
        y -= ny;
        ny = 0;
     }
   if (h <= 0)
      return 1;
   if ((y + h) > im->h)
      h = (im->h - y);
   if (h <= 0)
      return 1;
   if ((ny + h) > im->h)
      h = (im->h - ny);
   if (h <= 0)
      return 1;

   // figure out what our source and destnation start pointers are
   p1 = im->data + (y * im->w) + x;
   p2 = im->data + (ny * im->w) + nx;
   // the pointer jump between lines
   jump = (im->w - w);
   // dest < src address - we can copy forwards
   if (p2 < p1)
     {
        // work our way thru the array
        for (yy = 0; yy < h; yy++)
          {
             for (xx = 0; xx < w; xx++)
               {
                  *p2 = *p1;
                  p1++;
                  p2++;
               }
             p1 += jump;
             p2 += jump;
             if( sProgress && sProgress->calb3 ){
				const int bIfLastLine = (yy+1 == h);
				const int bEveryNthLine = !(yy % _IL2S_ProgressGranularity);
				if( bIfLastLine || bEveryNthLine ){
					float fPerc = ((double)yy+1) / h;
					if(!_il2s_call_user_callback( sProgress, fPerc,0,0, 0 )){
						return 0;
					}
				}
             }
          }
     }
   // dst > src - we must copy backwards
   else
     {
        // new pointers to start working at (bottom-right of rect)
        p1 = im->data + ((y + h - 1) * im->w) + x + w - 1;
        p2 = im->data + ((ny + h - 1) * im->w) + nx + w - 1;
        // work our way thru the array
        for (yy = 0; yy < h; yy++)
          {
             for (xx = 0; xx < w; xx++)
               {
                  *p2 = *p1;
                  p1--;
                  p2--;
               }
             p1 -= jump;
             p2 -= jump;

             if( sProgress && sProgress->calb3 ){
				const int bIfLastLine = (yy+1 == h),
						bEveryNthLine = !(yy % _IL2S_ProgressGranularity);
				if( bIfLastLine || bEveryNthLine ){
					float fPerc = ((double)yy+1) / h;
					if(!_il2s_call_user_callback( sProgress, fPerc,0,0, 0 )){
						return 0;
					}
				}
             }
          }
     }
   return 1;
}

/**
	Returns the width in pixels of the current image in Imlib2's context.

	old: imlib_image_get_width()
*/
IL2S_EAPI int
il2s_image_get_width( IL2S_Image img2 )
{
   ImlibImage         *im = img2;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_image_get_width", "image", img2, 0);
   //CAST_IMAGE(im, ctx->image);
   return im->w;
}
/**
	Returns the height in pixels of the current image in Imlib2's context.

	old: imlib_image_get_height()
*/
IL2S_EAPI int
il2s_image_get_height( IL2S_Image img2 )
{
   ImlibImage         *im = img2;

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_image_get_height", "image", img2, 0);
   //CAST_IMAGE(im, ctx->image);
   return im->h;
}
/**
	@param angle An angle in radians.
	@param nFlags Flags, can be: \ref IL2S_AntiAlias.

	@return A new image, or NULL.

	Creates an new copy of the current image, but rotated by @p angle
	radians. On success it returns a valid image handle, otherwise
	NULL.

	old: imlib_create_rotated_image()
**/
IL2S_EAPI IL2S_Image
il2s_create_rotated_image( IL2S_Image img2, double angle, int nFlags,
								il2s_progress_cb calb2, void* userr )
{
   ImlibImage         *im, *im_old = img2;
   int                 x, y, dx, dy, sz;
   double              x1, y1, d;

   _IL2S_InnerProgress sProgress = { calb2, userr, };

   //CHECK_CONTEXT(ctx);
   CHECK_PARAM_POINTER_RETURN("imlib_create_rotated_image", "image", img2, NULL);
   //CAST_IMAGE(im_old, ctx->image);
   if ((!(im_old->data)) && (im_old->loader) && (im_old->loader->load))
      im_old->loader->load(im_old, NULL, 0, 1);
   if (!(im_old->data))
      return NULL;

   d = hypot((double)(im_old->w + 4), (double)(im_old->h + 4)) / sqrt(2.0);

   x1 = (double)(im_old->w) / 2.0 - sin(angle + atan(1.0)) * d;
   y1 = (double)(im_old->h) / 2.0 - cos(angle + atan(1.0)) * d;

   sz = (int)(d * sqrt(2.0));
   x = (int)(x1 * _ROTATE_PREC_MAX);
   y = (int)(y1 * _ROTATE_PREC_MAX);
   dx = (int)(cos(angle) * _ROTATE_PREC_MAX);
   dy = -(int)(sin(angle) * _ROTATE_PREC_MAX);

   im = __imlib_CreateImage(sz, sz, NULL);
   im->data = calloc(sz * sz, sizeof(uint32_t));
   if (!(im->data))
     {
        __imlib_FreeImage(im);
        return NULL;
     }
   int rv2 = 0;
   if ( nFlags & IL2S_AntiAlias )  //ctx->anti_alias

     {
#ifdef DO_MMX_ASM
        if (__imlib_get_cpuid() & CPUID_MMX)
           rv2 = __imlib_mmx_RotateAA(im_old->data, im->data, im_old->w, im_old->w,
                                im_old->h, im->w, sz, sz, x, y, dx, dy, -dy,
                                dx);
           if( !_il2s_call_user_callback( &sProgress, 1.0f,0,0, 0 ) )
              rv2 = 0;
        else
#endif
           rv2 = __imlib_RotateAA(im_old->data, im->data, im_old->w, im_old->w,
                            im_old->h, im->w, sz, sz, x, y, dx, dy, -dy, dx,
                            &sProgress );
     }
   else
     {
        rv2 = __imlib_RotateSample(im_old->data, im->data, im_old->w, im_old->w,
                             im_old->h, im->w, sz, sz, x, y, dx, dy, -dy, dx,
                             &sProgress );
     }
   SET_FLAG(im->flags, F_HAS_ALPHA);

	if( rv2 ){
		return (IL2S_Image) im;
	}else{
		__imlib_FreeImage(im);
		return NULL;
	}
}
/**
	@param x The top left x coordinate of the rectangle.
	@param y The top left y coordinate of the rectangle.
	@param width The width of the rectangle.
	@param height The height of the rectangle.

	@param nFlags Flags parameter, 0 or \ref IL2S_Blend.
	@param eOperation Operation, eg. IL2S_OP_COPY.

	Draws a filled rectangle on the current image at the (@p x, @p y)
	coordinates with a size of @p width and @p height pixels, using the
	current color.

	old: imlib_image_fill_rectangle()
*/
IL2S_EAPI int
il2s_image_fill_rectangle( IL2S_Image img2,
								IL2S_Rect rect,
								uint32_t color, IL2S_Operation eOperation, int nFlags,
								il2s_progress_cb calb2, void* userr )
{
   ImlibImage         *im = img2;
   _IL2S_InnerProgress sProgress = { calb2, userr,};
   int x = rect.x, y = rect.y, width = rect.w, height = rect.h;

   CHECK_PARAM_POINTER("imlib_image_fill_rectangle", "image", img2);
   if ((!(im->data)) && (im->loader) && (im->loader->load))
      im->loader->load(im, NULL, 0, 1);
   if (!(im->data))
      return 0;
   SET_FLAG(im->flags, F_INVALID);   //__imlib_DirtyImage(im0);
   int bBlend = !!(nFlags & IL2S_Blend);   //ctx->blend
   return __imlib_Rectangle_FillToImage(
					x, y, width, height, color,
					im, 0,0,0,0,
					eOperation,   //ctx->operation
					bBlend, &sProgress );
}
/**
	@param x The top left x coordinate of the rectangle.
	@param y The top left y coordinate of the rectangle.
	@param width The width of the rectangle.
	@param height The height of the rectangle.
	@param new_x The top left x coordinate of the new location.
	@param new_y The top left y coordinate of the new location.

	Copies a rectangle of size @p width, @p height at the (@p x, @p y) location
	specified in the current image to a new location (@p new_x, @p new_y) in the same
	image.

	old: imlib_image_copy_rect()
*/
IL2S_EAPI void
il2s_image_copy_rect( IL2S_Image img2,
								IL2S_Rect source_rect,
								int new_x, int new_y,
								il2s_progress_cb calb2, void* userr )
{
   ImlibImage         *im3 = img2;
   _IL2S_InnerProgress sProgress = { calb2, userr, };
   int x = source_rect.x, y = source_rect.y, width = source_rect.w, height = source_rect.h;

   CHECK_PARAM_POINTER("il2s_image_copy_rect", "image", img2);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!(im3->data))
      return;
   SET_FLAG(im3->flags, F_INVALID);  //__imlib_DirtyImage(im3);
   __imlib_copy_image_data(im3, x, y, width, height, new_x, new_y, &sProgress );
}
/**
	@param x The top left x coordinate of the rectangle.
	@param y The top left y coordinate of the rectangle.
	@param width The width of the rectangle.
	@param height The height of the rectangle.
	@param nFlags flags, 0 or \ref IL2S_Blend.
	@param eOperation Operation, eg. IL2S_OP_COPY.

	Draws the outline of a rectangle on the current image at the (@p x,
	@p y)
	coordinates with a size of @p width and @p height pixels, using the
	current color.

	old: imlib_image_draw_rectangle()
*/
IL2S_EAPI int
il2s_image_draw_rectangle( IL2S_Image img2,
						IL2S_Rect rect,
						uint32_t color, IL2S_Operation eOperation, int nFlags,
						il2s_progress_cb calb2, void* userr )
{
	ImlibImage         *im3 = img2;
	_IL2S_InnerProgress sProgress = { calb2, userr,};
	int x = rect.x, y = rect.y, width = rect.w, height = rect.h;

	CHECK_PARAM_POINTER("imlib_image_draw_rectangle", "image", ctx->image);
	if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
		im3->loader->load(im3, NULL, 0, 1);
	if (!(im3->data))
		return 0;
	SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);
	int bBlend = !!(nFlags & IL2S_Blend);   //ctx->blend
	return __imlib_Rectangle_DrawToImage(x, y, width, height, color,
                                 im3, 0,0,0,0,
                                 eOperation, bBlend, &sProgress );
}
/**
	@param xc X coordinate of the center of the ellipse.
	@param yc Y coordinate of the center of the ellipse.
	@param a The horizontal amplitude of the ellipse.
	@param b The vertical amplitude of the ellipse.
	@param nFlags Flags, 0 or combination of:
			* \ref IL2S_AntiAlias
			* \ref IL2S_Blend
	@param eOperation Operation, eg. IL2S_OP_COPY.

	Draws an ellipse on the current context image. The ellipse is
	defined as (@p x-@p xc)^2/@p a^2 + (@p y-@p yc)^2/@p b^2 = 1. This means that the
	point (@p xc, @p yc) marks the center of the ellipse, @p a defines the
	horizontal amplitude of the ellipse, and @p b defines the vertical
	amplitude.

	old: imlib_image_draw_ellipse()
*/
IL2S_EAPI void
il2s_image_draw_ellipse( IL2S_Image img2, int xc, int yc, int a, int b,
							uint32_t color,
							IL2S_Operation eOperation, int nFlags )
{
   ImlibImage *im3 = img2;

   CHECK_PARAM_POINTER("il2s_image_draw_ellipse", "image", img2);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!(im3->data))
      return;

   int bAntiAlias2 = !!(nFlags & IL2S_AntiAlias);
   int bBlend      = !!(nFlags & IL2S_Blend);   //old: ctx->blend

   SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);
   __imlib_Ellipse_DrawToImage( xc, yc, a, b, color,
                               im3, 0,0,0,0,
                               eOperation, bBlend, bAntiAlias2 );
}
/**
	@param xc X coordinate of the center of the ellipse.
	@param yc Y coordinate of the center of the ellipse.
	@param a The horizontal amplitude of the ellipse.
	@param b The vertical amplitude of the ellipse.
	@param nFlags Flags, 0 or combination of:
			* \ref IL2S_AntiAlias
			* \ref IL2S_Blend
	@param eOperation Operation, eg. IL2S_OP_COPY.

	Fills an ellipse on the current context image using the current
	context color. The ellipse is
	defined as (@p x-@p xc)^2/@p a^2 + (@p y-@p yc)^2/@p b^2 = 1. This means that the
	point (@p xc, @p yc) marks the center of the ellipse, @p a defines the
	horizontal amplitude of the ellipse, and @p b defines the vertical
	amplitude.

	old: imlib_image_fill_ellipse()
*/
IL2S_EAPI void
il2s_image_fill_ellipse( IL2S_Image img2, int xc, int yc, int a, int b,
							uint32_t color,
							IL2S_Operation eOperation, int nFlags
							)
{
   ImlibImage *im3 = img2;
   // no progress callbacks, not implemented in the inner functions.
   _IL2S_InnerProgress sProgress = { 0, 0,};

   CHECK_PARAM_POINTER("imlib_fill_ellipse", "image", img2);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!(im3->data))
      return;

   int bAntiAlias2 = !!(nFlags & IL2S_AntiAlias);
   int bBlend      = !!(nFlags & IL2S_Blend);   //old: ctx->blend

   SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);
   __imlib_Ellipse_FillToImage( xc, yc, a, b, color,
                               im3, 0,0,0,0,
                               eOperation, bBlend, bAntiAlias2, &sProgress );
}
/**
	@param x1 The x coordinate of the first point.
	@param y1 The y coordinate of the first point.
	@param x2 The x coordinate of the second point.
	@param y2 The y coordinate of the second point.

	@param nFlags Flags, 0 or combination of:
			* \ref IL2S_AntiAlias
			* \ref IL2S_Blend

	@param eOperation Operation, eg. IL2S_OP_COPY.

	Draws a line using the current color on the current image from
	coordinates (@p x1, @p y1) to (@p x2, @p y2). If @p make_updates is 1
	it will also
	return an update you can use for an updates list, otherwise it
	returns NULL.

	old: imlib_image_draw_line()
*/
IL2S_EAPI void
il2s_image_draw_line( IL2S_Image img2,
						int x1, int y1, int x2, int y2,
						uint32_t color, IL2S_Operation eOperation, int nFlags )
{
   ImlibImage *im3 = img2;
   const char make_updates = 0;

   CHECK_PARAM_POINTER_RETURN("imlib_image_draw_line", "image", ctx->image,
                              NULL);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!(im3->data))
      return;//NULL

   SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);

   int bAntiAlias2 = !!(nFlags & IL2S_AntiAlias);
   int bBlend      = !!(nFlags & IL2S_Blend);   //old: ctx->blend
   //return (Imlib_Updates)
   __imlib_Line_DrawToImage( x1, y1, x2, y2, color, im3,
						   0,0,0,0,
						   eOperation, bBlend, bAntiAlias2,
						   make_updates );
}

/**
	@return A pointer to the image data.

	Returns a pointer to the image data in the image set as the image
	for the current context. When you get this pointer it is assumed you
	are planning on writing to the data, thus once you do this the image
	can no longer be used for caching - in fact all images cached from
	this one will also be affected when you put the data back. If this
	matters it is suggested you clone the image first before playing
	with the image data. The image data is returned in the format of a
	uint32_t (32 bits) per pixel in a linear array ordered from the top
	left of the image to the bottom right going from left to right each
	line. Each pixel has the upper 8 bits as the alpha channel and the
	lower 8 bits are the blue channel - so a pixel's bits are ARGB (from
	most to least significant, 8 bits per channel). You must put the
	data back at some point.

	old: imlib_image_get_data()
*/
IL2S_EAPI uint32_t*
il2s_image_get_data( IL2S_Image img2 )
{
   ImlibImage         *im3 = img2;

   CHECK_PARAM_POINTER_RETURN("il2s_image_get_data", "image", img2, NULL);
   if ((!(im3->data)) && (im3->loader) && (im3->loader->load))
      im3->loader->load(im3, NULL, 0, 1);
   if (!im3->data)
      return NULL;
   SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);
   return im3->data;
}


/**
	@param data The pointer to the image data.

	Puts back @p data when it was obtained by
	imlib_image_get_data(). @p data must be the same pointer returned
	by imlib_image_get_data(). This operated on the current context
	image.

	old: imlib_image_put_back_data()
*/
IL2S_EAPI void
il2s_image_put_back_data( IL2S_Image img2, uint32_t* data )
{
   ImlibImage         *im3 = img2;

   CHECK_PARAM_POINTER("il2s_image_put_back_data", "image", img2);
   CHECK_PARAM_POINTER("il2s_image_put_back_data", "data", data);
   SET_FLAG(im3->flags, F_INVALID);   //__imlib_DirtyImage(im3);
   data = NULL;
}

