#ifndef _IL2S_SPAN_H_INCLUDED_
#define _IL2S_SPAN_H_INCLUDED_


typedef void (*ImlibPointDrawFunction)(uint32_t, uint32_t *);

__hidden ImlibPointDrawFunction
__imlib_GetPointDrawFunction(ImlibOp op, char dst_alpha, char blend);


typedef void (*ImlibSpanDrawFunction)(uint32_t, uint32_t *, int);

__hidden ImlibSpanDrawFunction
__imlib_GetSpanDrawFunction(ImlibOp op, char dst_alpha, char blend);


typedef void (*ImlibShapedSpanDrawFunction)(uint8_t *, uint32_t, uint32_t *, int);

__hidden ImlibShapedSpanDrawFunction
__imlib_GetShapedSpanDrawFunction(ImlibOp op, char dst_alpha, char blend);


#endif //_IL2S_SPAN_H_INCLUDED_
