#include "il2s_common.h"
#include "il2s_colormod.h"
#include "il2s_image.h"
#include "il2s_blend.h"
#include "il2s_span.h"
//#include "updates.h"
#include "il2s_rgbadraw.h"

static int
__imlib_Rectangle_DrawToData(int x, int y, int rw, int rh, uint32_t color,
                             uint32_t * dst, int dstw, int clx, int cly, int clw,
                             int clh, ImlibOp op, char dst_alpha, char blend
                             ,const _IL2S_InnerProgress* sProgress
                             )
{
   ImlibPointDrawFunction pfunc;
   ImlibSpanDrawFunction sfunc;
   int                 x0, y0, x1, y1, len;
   uint32_t             *p;

   if (A_VAL(&color) == 0xff)
      blend = 0;

   sfunc = __imlib_GetSpanDrawFunction(op, dst_alpha, blend);
   pfunc = __imlib_GetPointDrawFunction(op, dst_alpha, blend);
   if (!pfunc || !sfunc)
      return 1;

   dst += (dstw * cly) + clx;
   x -= clx;
   y -= cly;

   x0 = x;
   x1 = x + rw - 1;

   if (x0 < 0)
      x0 = 0;
   if (x1 >= clw)
      x1 = clw - 1;

   if (y >= 0)
     {
        p = dst + (dstw * y) + x0;
        len = x1 - x0 + 1;
        sfunc(color, p, len);
     }
   if ((y + rh) <= clh)
     {
        p = dst + (dstw * (y + rh - 1)) + x0;
        len = x1 - x0 + 1;
        sfunc(color, p, len);
     }

   y0 = y + 1;
   y1 = y + rh - 2;

   if (y0 < 0)
      y0 = 0;
   if (y1 >= clh)
      y1 = clh - 1;

   len = y1 - y0 + 1;
   if (len <= 0)
      return 1;
   y1 = len;
   if(!_il2s_call_user_callback( sProgress, 0.0f, 0, 0, 0 ))
      return 0;
   if (x >= 0)
     {
        p = dst + (dstw * y0) + x;
        while (len--)
          {
             pfunc(color, p);
             p += dstw;
          }
     }
   if ((x + rw) <= clw)
     {
        len = y1;
        p = dst + (dstw * y0) + x + rw - 1;
        while (len--)
          {
             pfunc(color, p);
             p += dstw;
          }
     }
   if(!_il2s_call_user_callback( sProgress, 1.0f, 0, 0, 0 ))
      return 0;
   return 1;
}

static int
__imlib_Rectangle_FillToData(int x, int y, int rw, int rh, uint32_t color,
                             uint32_t * dst, int dstw, int clx, int cly, int clw,
                             int clh, ImlibOp op, char dst_alpha, char blend,
                             const _IL2S_InnerProgress* sProgress
                             )
{
   ImlibSpanDrawFunction sfunc;
   uint32_t             *p;

   if (A_VAL(&color) == 0xff)
      blend = 0;
   sfunc = __imlib_GetSpanDrawFunction(op, dst_alpha, blend);
   if (!sfunc)
      return 1;

   dst += (dstw * cly) + clx;
   x -= clx;
   y -= cly;

   CLIP_RECT_TO_RECT(x, y, rw, rh, 0, 0, clw, clh);
   if ((rw < 1) || (rh < 1))
      return 1;

   p = dst + (dstw * y) + x;
   const int heightt = rh;
   while (rh--)
     {
        sfunc(color, p, rw);
        p += dstw;

		if( sProgress && sProgress->calb3 ){
			const int idxLine = heightt - rh;
			const int bIfLastLine = (idxLine == heightt);
			const int bEveryNthLine = !(idxLine % _IL2S_ProgressGranularity);
			if( bIfLastLine || bEveryNthLine ){
				float fPerc = ((double)idxLine) / heightt;
				if( !_il2s_call_user_callback( sProgress, fPerc,0,0, 0 ) )
					return 0;
			}
		}
     }
     return 1;
}

int
__imlib_Rectangle_DrawToImage(int x, int y, int w, int h, uint32_t color,
                              ImlibImage * im, int clx, int cly, int clw,
                              int clh, ImlibOp op, char blend
                              ,const _IL2S_InnerProgress* sProgress
                              )
{
   if ((w < 1) || (h < 1) || (clw < 0))
      return 1;
   if ((w == 1) || (h == 1))
     {
        (void)__imlib_Line_DrawToImage(x, y, x + w - 1, y + h - 1, color,
                                       im, clx, cly, clw, clh, op, blend, 0, 0);

	   if(!_il2s_call_user_callback( sProgress, 1.0f,0,0, 0 ))
		  return 0;
        return 1;
     }
   if (blend && (!A_VAL(&color)))
      return 1;

   if (clw == 0)
     {
        clw = im->w;
        clx = 0;
        clh = im->h;
        cly = 0;
     }

   CLIP_RECT_TO_RECT(clx, cly, clw, clh, 0, 0, im->w, im->h);
   if ((clw < 1) || (clh < 1))
      return 1;

   CLIP_RECT_TO_RECT(clx, cly, clw, clh, x, y, w, h);
   if ((clw < 1) || (clh < 1))
      return 1;

   if (blend && IMAGE_HAS_ALPHA(im))
      __imlib_build_pow_lut();

   return __imlib_Rectangle_DrawToData(x, y, w, h, color,
                                im->data, im->w, clx, cly, clw, clh,
                                op, IMAGE_HAS_ALPHA(im), blend, sProgress );
}

int
__imlib_Rectangle_FillToImage(int x, int y, int w, int h, uint32_t color,
                              ImlibImage * im, int clx, int cly, int clw,
                              int clh, ImlibOp op, char blend,
                              const _IL2S_InnerProgress* sProgress )
{
   if ((w < 1) || (h < 1) || (clw < 0))
      return 1;
   if ((w == 1) || (h == 1))
     {
        (void)__imlib_Line_DrawToImage(x, y, x + w - 1, y + h - 1, color,
                                       im, clx, cly, clw, clh, op, blend, 0, 0);

	   if( !_il2s_call_user_callback( sProgress, 1.0f,0,0, 0 ) )
		  return 0;
        return 1;
     }
   if (blend && (!A_VAL(&color)))
      return 1;

   if (clw == 0)
     {
        clw = im->w;
        clx = 0;
        clh = im->h;
        cly = 0;
     }

   CLIP_RECT_TO_RECT(clx, cly, clw, clh, 0, 0, im->w, im->h);
   if ((clw < 1) || (clh < 1))
      return 1;

   CLIP_RECT_TO_RECT(clx, cly, clw, clh, x, y, w, h);
   if ((clw < 1) || (clh < 1))
      return 1;

   if (blend && IMAGE_HAS_ALPHA(im))
      __imlib_build_pow_lut();

   return __imlib_Rectangle_FillToData(x, y, w, h, color,
                                im->data, im->w, clx, cly, clw, clh,
                                op, IMAGE_HAS_ALPHA(im), blend,
                                sProgress );
}
