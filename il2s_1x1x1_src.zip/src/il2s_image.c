#include "il2s_common.h"
#ifdef BUILD_X11
#include <X11/Xlib.h>
#endif
#include "il2s_image.h"

static ImlibImage  *images = NULL;

#ifdef BUILD_X11
static ImlibImagePixmap *pixmaps = NULL;
#endif
//static ImlibLoader *loaders = NULL;
static int          cache_size = 4096 * 1024;


/* create a new image struct from data passed that is wize w x h then return */
/* a pointer to that image sturct */
ImlibImage         *
__imlib_CreateImage(int w, int h, uint32_t * data)
{
   ImlibImage         *im;

   im = __imlib_ProduceImage();
   im->w = w;
   im->h = h;
   im->data = data;
   im->references = 1;
   SET_FLAG(im->flags, F_UNCACHEABLE);
   return im;
}


/* free and image - if its uncachable and refcoutn is 0 - free it in reality */
void
__imlib_FreeImage(ImlibImage * im)
{
   /* if the refcount is positive */
   if (im->references >= 0)
     {
        /* reduce a reference from the count */
        im->references--;
        /* if its uncachchable ... */
        if (IMAGE_IS_UNCACHEABLE(im))
          {
             /* and we're down to no references for the image then free it */
             if (im->references == 0)
                __imlib_ConsumeImage(im);
          }
        /* otherwise clean up our cache if the image becoem 0 ref count */
        else if (im->references == 0)
           __imlib_CleanupImageCache();
     }
}


/* create an image data struct and fill it in */
ImlibImage         *
__imlib_ProduceImage(void)
{
   ImlibImage         *im;

   im = calloc(1, sizeof(ImlibImage));
   im->data = NULL;
   im->file = NULL;
   im->real_file = NULL;
   im->key = NULL;
   im->flags = F_FORMAT_IRRELEVANT | F_BORDER_IRRELEVANT | F_ALPHA_IRRELEVANT;
   im->loader = NULL;
   im->next = NULL;
   im->tags = NULL;
   return im;
}

/* free an image struct */
void
__imlib_ConsumeImage(ImlibImage * im)
{
#ifdef BUILD_X11
   ImlibImagePixmap   *ip;
#endif

   __imlib_FreeAllTags(im);
   if (im->file)
      free(im->file);
   if (im->real_file)
      free(im->real_file);
   if (im->key)
      free(im->key);
   if ((IMAGE_FREE_DATA(im)) && (im->data))
      free(im->data);
   if (im->format)
      free(im->format);
   free(im);
#ifdef BUILD_X11
   ip = pixmaps;
   while (ip)
     {
        if (ip->image == im)
          {
             ip->image = NULL;
             ip->dirty = 1;
          }
        ip = ip->next;
     }
#endif
}

/* clean out images fromthe cache if the cache is overgrown */
void
__imlib_CleanupImageCache(void)
{
   ImlibImage         *im, *im_last;
   int                 current_cache;
   char                operation = 1;

   current_cache = __imlib_CurrentCacheSize();
   im_last = NULL;
   im = images;
   /* remove 0 ref count invalid (dirty) images */
   while (im)
     {
        im_last = im;
        im = im->next;
        if ((im_last->references <= 0) && (!(IMAGE_IS_VALID(im_last))))
          {
             __imlib_RemoveImageFromCache(im_last);
             __imlib_ConsumeImage(im_last);
          }
     }
   /* while the cache size of 0 ref coutn data is bigger than the set value */
   /* clean out the oldest members of the imaeg cache */
   while ((current_cache > cache_size) && (operation))
     {
        im_last = NULL;
        operation = 0;
        im = images;
        while (im)
          {
             if (im->references <= 0)
                im_last = im;
             im = im->next;
          }
        if (im_last)
          {
             __imlib_RemoveImageFromCache(im_last);
             __imlib_ConsumeImage(im_last);
             operation = 1;
          }
        if (operation)
           current_cache = __imlib_CurrentCacheSize();
     }
}
/* free all the tags attached to an image */
void
__imlib_FreeAllTags(ImlibImage * im)
{
   ImlibImageTag      *t, *tt;

   t = im->tags;
   while (t)
     {
        tt = t;
        t = t->next;
        __imlib_FreeTag(im, tt);
     }
}

/* work out how much we have floaitng aroudn in our speculative cache */
/* (images and pixmaps that have 0 reference counts) */
int
__imlib_CurrentCacheSize(void)
{
   ImlibImage         *im;

#ifdef BUILD_X11
   ImlibImagePixmap   *ip;
#endif
   int                 current_cache = 0;

   /* go through the image cache */
   im = images;
   while (im)
     {
        /* mayaswell clean out stuff thats invalid that we dont need anymore */
        if (im->references == 0)
          {
             if (!(IMAGE_IS_VALID(im)))
               {
                  ImlibImage         *tmp_im;

                  tmp_im = im;
                  im = im->next;
                  __imlib_RemoveImageFromCache(tmp_im);
                  __imlib_ConsumeImage(tmp_im);
#ifdef BUILD_X11
                  ip = pixmaps;
                  while (ip)
                    {
                       if (ip->image == tmp_im)
                         {
                            ip->image = NULL;
                            ip->dirty = 1;
                         }
                       ip = ip->next;
                    }
#endif
                  continue;
               }
             /* it's valid but has 0 ref's - append to cache size count */
             else
                current_cache += im->w * im->h * sizeof(uint32_t);
          }
        im = im->next;
     }
#ifdef BUILD_X11
   /* go through the pixmaps */
   ip = pixmaps;
   while (ip)
     {
        /* if the pixmap has 0 references */
        if (ip->references == 0)
          {
             /* if the image is invalid */
             if ((ip->dirty) || ((ip->image) && (!(IMAGE_IS_VALID(ip->image)))))
               {
                  ImlibImagePixmap   *tmp_ip;

                  tmp_ip = ip;
                  ip = ip->next;
                  __imlib_RemoveImagePixmapFromCache(tmp_ip);
                  __imlib_ConsumeImagePixmap(tmp_ip);
                  continue;
               }
             else
               {
                  /* add the pixmap data size to the cache size */
                  if (ip->pixmap)
                    {
                       if (ip->depth < 8)
                          current_cache += ip->w * ip->h * (ip->depth / 8);
                       else if (ip->depth == 8)
                          current_cache += ip->w * ip->h;
                       else if (ip->depth <= 16)
                          current_cache += ip->w * ip->h * 2;
                       else if (ip->depth <= 32)
                          current_cache += ip->w * ip->h * 4;
                    }
                  /* if theres a mask add it too */
                  if (ip->mask)
                     current_cache += ip->w * ip->h / 8;
               }
          }
        ip = ip->next;
     }
#endif
   return current_cache;
}

/* remove (unlink) an image from the cache of images */
void
__imlib_RemoveImageFromCache(ImlibImage * im)
{
   ImlibImage         *current_im, *previous_im;

   current_im = images;
   previous_im = NULL;
   while (current_im)
     {
        if (im == current_im)
          {
             if (previous_im)
                previous_im->next = im->next;
             else
                images = im->next;
             return;
          }
        previous_im = current_im;
        current_im = current_im->next;
     }
}
/* free the data struct for the tag and if a destructor function was */
/* provided call it on the data member */
void
__imlib_FreeTag(ImlibImage * im, ImlibImageTag * t)
{
   free(t->key);
   if (t->destructor)
      t->destructor(im, t->data);
   free(t);
}
