
// enabling AMD64 Assembly
#define DO_AMD64_ASM 1

// enabling MMX Assembly (32-bit architecture)
// #undef DO_MMX_ASM

// Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
// significant byte first (like Motorola and SPARC, unlike Intel).
#if defined AC_APPLE_UNIVERSAL_BUILD
#	if defined __BIG_ENDIAN__
#		define WORDS_BIGENDIAN 1
#	endif
#endif

