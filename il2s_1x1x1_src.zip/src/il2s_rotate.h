#ifndef _IL2S_ROTATE_H_INCLUDED_
#define _IL2S_ROTATE_H_INCLUDED_


#include "../inc/il2s/il2s_api.h"
#include "il2s_colormod.h"
#include "il2s_image.h"
#include "il2s_blend.h"

/*\ Calc precision \*/
#define _ROTATE_PREC 12
#define _ROTATE_PREC_MAX (1 << _ROTATE_PREC)
#define _ROTATE_PREC_BITS (_ROTATE_PREC_MAX - 1)

__hidden int __imlib_RotateSample(uint32_t *src, uint32_t *dest, int sow, int sw, int sh,
			  int dow, int dw, int dh, int x, int y,
			  int dxh, int dyh, int dxv, int dyv,
			  const _IL2S_InnerProgress* sProgress
			  );
__hidden int __imlib_RotateAA(uint32_t *src, uint32_t *dest, int sow, int sw, int sh,
		      int dow, int dw, int dh, int x, int y,
		      int dx, int dy, int dxv, int dyv,
		      const _IL2S_InnerProgress* sProgress
		      );
__hidden void __imlib_BlendImageToImageSkewed(ImlibImage *im_src, ImlibImage *im_dst,
				     char aa, char blend, char merge_alpha,
				     int ssx, int ssy, int ssw, int ssh,
				     int ddx, int ddy,
				     int hsx, int hsy, int vsx, int vsy,
				     ImlibColorModifier *cm, ImlibOp op,
				     int clx, int cly, int clw, int clh
				     //_IL2S_InnerProgress
				     );

#ifdef DO_MMX_ASM
__hidden void __imlib_mmx_RotateAA(uint32_t *src, uint32_t *dest, int sow, int sw, int sh,
			  int dow, int dw, int dh, int x, int y,
			  int dx, int dy, int dxv, int dyv);
#endif
#endif //_IL2S_ROTATE_H_INCLUDED_
